# Pods Battery

Appli Android qui affiche la batterie des AirPods (gauche, droit, boîtier) en lisant
le signal Bluetooth LE qu'ils diffusent. Testée pour Android 12+ (Galaxy S23 FE OK).

## Compiler l'APK avec GitHub (gratuit, sans rien installer)

1. Crée un compte sur github.com puis un nouveau dépôt (ex. `pods-battery`).
2. Sur la page du dépôt : **Add file → Upload files**, et glisse **le contenu** du dossier
   `PodsBattery` (dossiers `app`, `.github` et les fichiers `.kts` / `.properties`).
   Astuce : le dossier `.github` est caché sur certains PC, affiche les fichiers cachés.
3. Valide ("Commit changes"). L'onglet **Actions** lance la compilation (~5 min).
4. Ouvre le build terminé → en bas, **Artifacts → PodsBattery-apk** → télécharge le zip,
   il contient `app-debug.apk`.

## Compiler avec Android Studio

Ouvre le dossier `PodsBattery`, attends la synchro Gradle, puis **Build → Build APK(s)**.

## Installer sur le téléphone

Ouvre `app-debug.apk` sur le Samsung → autorise l'installation depuis cette source →
Installer. Au premier lancement, accepte la permission « Appareils à proximité » et
garde la localisation activée (exigence d'Android pour scanner le Bluetooth).

## Limites

- Précision par paliers de 10 % (c'est ce que les AirPods envoient).
- La charge du boîtier n'apparaît que boîtier ouvert.
- Le scan tourne seulement quand l'appli est ouverte.

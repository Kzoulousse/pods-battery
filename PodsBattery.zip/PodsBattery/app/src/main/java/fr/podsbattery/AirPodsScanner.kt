package fr.podsbattery

import android.annotation.SuppressLint
import android.bluetooth.BluetoothManager
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

data class ScanDebug(
    val scanning: Boolean = false,
    val totalPackets: Int = 0,
    val applePackets: Int = 0,
    val podsPackets: Int = 0,
    val lastAppleHex: String = "",
    val error: String? = null,
)

class AirPodsScanner(context: Context) {

    private val adapter = context.getSystemService(BluetoothManager::class.java)?.adapter
    private val _status = MutableStateFlow<PodsStatus?>(null)
    val status: StateFlow<PodsStatus?> = _status
    private val _debug = MutableStateFlow(ScanDebug())
    val debug: StateFlow<ScanDebug> = _debug
    private var scanning = false

    private val settings = ScanSettings.Builder()
        .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)
        .setCallbackType(ScanSettings.CALLBACK_TYPE_ALL_MATCHES)
        .setMatchMode(ScanSettings.MATCH_MODE_AGGRESSIVE)
        .setNumOfMatches(ScanSettings.MATCH_NUM_MAX_ADVERTISEMENT)
        .setReportDelay(0)
        .build()

    private val callback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) = handle(result)
        override fun onBatchScanResults(results: MutableList<ScanResult>) = results.forEach { handle(it) }
        override fun onScanFailed(errorCode: Int) {
            scanning = false
            _debug.value = _debug.value.copy(scanning = false, error = "Échec du scan (code $errorCode)")
        }
    }

    private fun handle(result: ScanResult) {
        var dbg = _debug.value.copy(totalPackets = _debug.value.totalPackets + 1)
        val data = result.scanRecord?.getManufacturerSpecificData(APPLE_ID)
        if (data == null) { _debug.value = dbg; return }

        dbg = dbg.copy(
            applePackets = dbg.applePackets + 1,
            lastAppleHex = data.take(12).joinToString("") { "%02X".format(it) }
        )
        val parsed = AirPodsParser.parse(data, result.rssi)
        if (parsed == null || parsed.rssi < MIN_RSSI) { _debug.value = dbg; return }
        _debug.value = dbg.copy(podsPackets = dbg.podsPackets + 1)

        // Garde l'appareil au signal le plus fort (= les tiens, pas ceux du voisin)
        val current = _status.value
        val replace = current == null ||
            parsed.timestamp - current.timestamp > 5_000 ||
            parsed.rssi >= current.rssi - 8
        if (replace) _status.value = parsed
    }

    fun isBluetoothOn(): Boolean = adapter?.isEnabled == true

    @SuppressLint("MissingPermission")
    fun start() {
        if (scanning) return
        val le = adapter?.bluetoothLeScanner
        if (le == null) {
            _debug.value = _debug.value.copy(error = "Scanner Bluetooth indisponible")
            return
        }
        try {
            // Aucun filtre matériel : certains Samsung ignorent les filtres "fabricant".
            // Le tri se fait dans handle().
            le.startScan(null, settings, callback)
            scanning = true
            _debug.value = _debug.value.copy(scanning = true, error = null)
        } catch (e: Exception) {
            _debug.value = _debug.value.copy(scanning = false, error = e.javaClass.simpleName + " : " + e.message)
        }
    }

    @SuppressLint("MissingPermission")
    fun stop() {
        if (!scanning) return
        runCatching { adapter?.bluetoothLeScanner?.stopScan(callback) }
        scanning = false
        _debug.value = _debug.value.copy(scanning = false)
    }

    companion object {
        const val APPLE_ID = 0x004C
        const val MIN_RSSI = -90
    }
}

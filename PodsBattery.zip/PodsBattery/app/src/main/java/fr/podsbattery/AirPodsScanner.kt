package fr.podsbattery

import android.annotation.SuppressLint
import android.bluetooth.BluetoothManager
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanFilter
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

class AirPodsScanner(context: Context) {

    private val adapter = context.getSystemService(BluetoothManager::class.java)?.adapter
    private val _status = MutableStateFlow<PodsStatus?>(null)
    val status: StateFlow<PodsStatus?> = _status
    private var scanning = false

    private val filters = listOf(
        ScanFilter.Builder()
            .setManufacturerData(APPLE_ID, byteArrayOf(0x07, 0x19), byteArrayOf(-1, -1))
            .build()
    )
    private val settings = ScanSettings.Builder()
        .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)
        .setReportDelay(0)
        .build()

    private val callback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) = handle(result)
        override fun onBatchScanResults(results: MutableList<ScanResult>) = results.forEach { handle(it) }
    }

    private fun handle(result: ScanResult) {
        val data = result.scanRecord?.getManufacturerSpecificData(APPLE_ID) ?: return
        val parsed = AirPodsParser.parse(data, result.rssi) ?: return
        if (parsed.rssi < MIN_RSSI) return
        // Garde l'appareil au signal le plus fort (= les tiens, pas ceux du voisin)
        val current = _status.value
        val replace = current == null ||
            parsed.timestamp - current.timestamp > 5_000 ||
            parsed.rssi >= current.rssi - 8
        if (replace) _status.value = parsed
    }

    fun isBluetoothOn(): Boolean = adapter?.isEnabled == true

    @SuppressLint("MissingPermission")
    fun start() {
        if (scanning) return
        val le = adapter?.bluetoothLeScanner ?: return
        runCatching {
            le.startScan(filters, settings, callback)
            scanning = true
        }
    }

    @SuppressLint("MissingPermission")
    fun stop() {
        if (!scanning) return
        runCatching { adapter?.bluetoothLeScanner?.stopScan(callback) }
        scanning = false
    }

    companion object {
        const val APPLE_ID = 0x004C
        const val MIN_RSSI = -85
    }
}

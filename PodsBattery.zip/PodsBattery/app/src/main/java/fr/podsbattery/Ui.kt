package fr.podsbattery

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.LocationManager
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LifecycleResumeEffect
import kotlinx.coroutines.delay

// ---------- Palette ----------
private val BgTop = Color(0xFF101A2C)
private val BgBottom = Color(0xFF05070C)
private val CardBg = Color(0x14FFFFFF)
private val Track = Color(0x1FFFFFFF)
private val White = Color(0xFFF4F6FA)
private val Muted = Color(0xFF8B95A7)
private val Faint = Color(0xFF5A6476)
private val Green = Color(0xFF34D399)
private val Amber = Color(0xFFFBBF24)
private val Red = Color(0xFFF87171)
private val Gray = Color(0xFF4B5563)

private fun levelColor(p: Int?) = when {
    p == null -> Gray
    p <= 20 -> Red
    p <= 50 -> Amber
    else -> Green
}

// ---------- Permissions & état système ----------
private val PERMS = arrayOf(
    Manifest.permission.BLUETOOTH_SCAN,
    Manifest.permission.ACCESS_FINE_LOCATION,
    Manifest.permission.ACCESS_COARSE_LOCATION,
)

private fun hasPerms(c: Context) =
    PERMS.all { ContextCompat.checkSelfPermission(c, it) == PackageManager.PERMISSION_GRANTED }

private fun isLocationOn(c: Context) =
    c.getSystemService(LocationManager::class.java)?.isLocationEnabled == true

private enum class Screen { PERMS, BT_OFF, LOC_OFF, SEARCHING, READY }

@Composable
fun App(scanner: AirPodsScanner) {
    val ctx = LocalContext.current
    var perms by remember { mutableStateOf(hasPerms(ctx)) }
    var btOn by remember { mutableStateOf(scanner.isBluetoothOn()) }
    var locOn by remember { mutableStateOf(isLocationOn(ctx)) }
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    val status by scanner.status.collectAsState()
    val debug by scanner.debug.collectAsState()

    val launcher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { perms = hasPerms(ctx) }

    // Rafraîchit l'horloge et l'état Bluetooth / localisation chaque seconde
    LaunchedEffect(Unit) {
        while (true) {
            now = System.currentTimeMillis()
            perms = hasPerms(ctx)
            btOn = scanner.isBluetoothOn()
            locOn = isLocationOn(ctx)
            delay(1000)
        }
    }

    // Scanne uniquement quand l'appli est au premier plan
    LifecycleResumeEffect(perms, btOn, locOn) {
        if (perms && btOn && locOn) scanner.start()
        onPauseOrDispose { scanner.stop() }
    }

    val s = status
    val screen = when {
        !perms -> Screen.PERMS
        !btOn -> Screen.BT_OFF
        !locOn -> Screen.LOC_OFF
        s == null || now - s.timestamp > 30_000 -> Screen.SEARCHING
        else -> Screen.READY
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = Green)) {
        Box(
            Modifier
                .fillMaxSize()
                .background(Brush.verticalGradient(listOf(BgTop, BgBottom)))
        ) {
            Column(
                Modifier
                    .fillMaxSize()
                    .systemBarsPadding()
                    .padding(horizontal = 24.dp, vertical = 16.dp)
            ) {
                Header(if (screen == Screen.READY && s != null) s.model else "AirPods")
                Crossfade(
                    targetState = screen,
                    label = "screen",
                    modifier = Modifier.weight(1f).fillMaxWidth()
                ) { sc ->
                    when (sc) {
                        Screen.PERMS -> SetupView(
                            emoji = "📡",
                            title = "Autorisation nécessaire",
                            body = "L'appli écoute le signal Bluetooth que tes AirPods envoient pour lire leur batterie. Rien n'est enregistré ni envoyé.",
                            action = "Autoriser",
                            onAction = { launcher.launch(PERMS) },
                            secondaryLabel = "Ouvrir les réglages de l'appli",
                            onSecondary = {
                                ctx.startActivity(
                                    Intent(
                                        Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                        Uri.fromParts("package", ctx.packageName, null)
                                    ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                )
                            },
                        )
                        Screen.BT_OFF -> SetupView(
                            emoji = "🔵",
                            title = "Bluetooth désactivé",
                            body = "Active le Bluetooth pour détecter tes AirPods.",
                            action = "Ouvrir le Bluetooth",
                            onAction = {
                                ctx.startActivity(
                                    Intent(Settings.ACTION_BLUETOOTH_SETTINGS)
                                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                )
                            },
                        )
                        Screen.LOC_OFF -> SetupView(
                            emoji = "📍",
                            title = "Localisation désactivée",
                            body = "Android exige la localisation activée pour scanner le Bluetooth. L'appli n'utilise pas ta position.",
                            action = "Activer la localisation",
                            onAction = {
                                ctx.startActivity(
                                    Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)
                                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                )
                            },
                        )
                        Screen.SEARCHING -> SearchingView(debug)
                        Screen.READY -> if (s != null) PodsView(s, now) else SearchingView(debug)
                    }
                }
            }
        }
    }
}

@Composable
private fun Header(title: String) {
    Column(Modifier.padding(top = 8.dp, bottom = 8.dp)) {
        Text(
            "BATTERIE",
            color = Muted,
            fontSize = 13.sp,
            letterSpacing = 2.sp,
            fontWeight = FontWeight.SemiBold
        )
        Text(title, color = White, fontSize = 30.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun SetupView(
    emoji: String,
    title: String,
    body: String,
    action: String,
    onAction: () -> Unit,
    secondaryLabel: String? = null,
    onSecondary: () -> Unit = {},
) {
    Column(
        Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(emoji, fontSize = 56.sp)
        Spacer(Modifier.height(16.dp))
        Text(
            title,
            color = White,
            fontSize = 22.sp,
            fontWeight = FontWeight.SemiBold,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(8.dp))
        Text(
            body,
            color = Muted,
            fontSize = 15.sp,
            lineHeight = 21.sp,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(28.dp))
        Button(
            onClick = onAction,
            shape = RoundedCornerShape(50),
            colors = ButtonDefaults.buttonColors(
                containerColor = Green,
                contentColor = Color(0xFF04120C)
            )
        ) {
            Text(
                action,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
            )
        }
        if (secondaryLabel != null) {
            TextButton(onClick = onSecondary) { Text(secondaryLabel, color = Muted) }
        }
    }
}

@Composable
private fun SearchingView(debug: ScanDebug) {
    val t = rememberInfiniteTransition(label = "search")
    val phase by t.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(2200, easing = LinearEasing)),
        label = "phase"
    )
    Column(
        Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(Modifier.size(220.dp), contentAlignment = Alignment.Center) {
            Canvas(Modifier.fillMaxSize()) {
                val maxR = size.minDimension / 2f
                for (i in 0 until 3) {
                    val p = (phase + i / 3f) % 1f
                    drawCircle(
                        color = Green.copy(alpha = (1f - p) * 0.5f),
                        radius = maxR * (0.25f + 0.75f * p),
                        style = Stroke(width = 2.dp.toPx())
                    )
                }
                drawCircle(color = Green.copy(alpha = 0.15f), radius = maxR * 0.25f)
            }
            Text("🎧", fontSize = 40.sp)
        }
        Spacer(Modifier.height(24.dp))
        Text(
            "Recherche des AirPods…",
            color = White,
            fontSize = 20.sp,
            fontWeight = FontWeight.SemiBold
        )
        Spacer(Modifier.height(8.dp))
        Text(
            "Ouvre le boîtier à côté du téléphone,\nou mets les écouteurs dans tes oreilles.",
            color = Muted,
            fontSize = 15.sp,
            lineHeight = 21.sp,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(32.dp))
        // Diagnostic (à envoyer si ça ne marche pas)
        Column(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(CardBg)
                .padding(14.dp)
        ) {
            Text("Diagnostic", color = Muted, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(4.dp))
            Text(
                "Scan : " + (if (debug.scanning) "actif" else "arrêté") +
                    "\nAppareils Bluetooth captés : ${debug.totalPackets}" +
                    "\nSignaux Apple : ${debug.applePackets}" +
                    "\nSignaux AirPods : ${debug.podsPackets}" +
                    (if (debug.lastAppleHex.isNotEmpty()) "\nDernier Apple : ${debug.lastAppleHex}" else "") +
                    (debug.error?.let { "\nErreur : $it" } ?: ""),
                color = Faint,
                fontSize = 12.sp,
                lineHeight = 17.sp
            )
        }
    }
}

@Composable
private fun PodsView(s: PodsStatus, now: Long) {
    Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(Modifier.weight(1f))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            BatteryRing("Gauche", s.left, s.leftCharging, 136.dp)
            BatteryRing("Droit", s.right, s.rightCharging, 136.dp)
        }
        Spacer(Modifier.height(32.dp))
        CaseCard(s.case, s.caseCharging)
        Spacer(Modifier.weight(1f))

        val ago = ((now - s.timestamp) / 1000).coerceAtLeast(0)
        val signal = when {
            s.rssi > -55 -> "fort"
            s.rssi > -70 -> "moyen"
            else -> "faible"
        }
        Text(
            "Signal $signal · mis à jour il y a $ago s",
            color = Muted,
            fontSize = 13.sp,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(4.dp))
        Text(
            "Précision ±10 % : les AirPods n'envoient que des paliers de 10 %.",
            color = Faint,
            fontSize = 12.sp,
            textAlign = TextAlign.Center
        )
    }
}

@Composable
private fun BatteryRing(label: String, percent: Int?, charging: Boolean, ringSize: Dp) {
    val progress by animateFloatAsState(
        targetValue = (percent ?: 0) / 100f,
        animationSpec = tween(1000, easing = FastOutSlowInEasing),
        label = "ring"
    )
    val color = levelColor(percent)
    val t = rememberInfiniteTransition(label = "glow")
    val glow by t.animateFloat(
        initialValue = 0.12f,
        targetValue = 0.4f,
        animationSpec = infiniteRepeatable(tween(1100), RepeatMode.Reverse),
        label = "glowAlpha"
    )

    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(ringSize), contentAlignment = Alignment.Center) {
            Canvas(Modifier.fillMaxSize()) {
                val stroke = size.minDimension * 0.08f
                val inset = stroke / 2f + 4.dp.toPx()
                val arcSize = Size(size.width - inset * 2, size.height - inset * 2)
                val topLeft = Offset(inset, inset)
                drawArc(
                    color = Track,
                    startAngle = 135f,
                    sweepAngle = 270f,
                    useCenter = false,
                    topLeft = topLeft,
                    size = arcSize,
                    style = Stroke(width = stroke, cap = StrokeCap.Round)
                )
                if (percent != null) {
                    if (charging) {
                        drawArc(
                            color = color.copy(alpha = glow),
                            startAngle = 135f,
                            sweepAngle = 270f * progress,
                            useCenter = false,
                            topLeft = topLeft,
                            size = arcSize,
                            style = Stroke(width = stroke * 2.2f, cap = StrokeCap.Round)
                        )
                    }
                    drawArc(
                        color = color,
                        startAngle = 135f,
                        sweepAngle = 270f * progress,
                        useCenter = false,
                        topLeft = topLeft,
                        size = arcSize,
                        style = Stroke(width = stroke, cap = StrokeCap.Round)
                    )
                }
            }
            Row(verticalAlignment = Alignment.Bottom) {
                Text(
                    percent?.toString() ?: "—",
                    color = if (percent == null) Muted else White,
                    fontSize = 40.sp,
                    fontWeight = FontWeight.Bold
                )
                if (percent != null) {
                    Text(
                        "%",
                        color = Muted,
                        fontSize = 18.sp,
                        modifier = Modifier.padding(start = 2.dp, bottom = 7.dp)
                    )
                }
            }
        }
        Spacer(Modifier.height(4.dp))
        Text(
            (if (charging) "⚡ " else "") + label,
            color = if (charging) color else Muted,
            fontSize = 15.sp,
            fontWeight = FontWeight.Medium
        )
    }
}

@Composable
private fun CaseCard(percent: Int?, charging: Boolean) {
    val progress by animateFloatAsState(
        targetValue = (percent ?: 0) / 100f,
        animationSpec = tween(1000, easing = FastOutSlowInEasing),
        label = "case"
    )
    val color = levelColor(percent)
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(CardBg)
            .padding(20.dp)
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(
                (if (charging) "⚡ " else "") + "Boîtier",
                color = White,
                fontSize = 17.sp,
                fontWeight = FontWeight.Medium,
                modifier = Modifier.weight(1f)
            )
            Text(
                percent?.let { "$it %" } ?: "—",
                color = if (percent == null) Muted else White,
                fontSize = 17.sp,
                fontWeight = FontWeight.SemiBold
            )
        }
        Spacer(Modifier.height(12.dp))
        Box(
            Modifier
                .fillMaxWidth()
                .height(10.dp)
                .clip(RoundedCornerShape(50))
                .background(Track)
        ) {
            Box(
                Modifier
                    .fillMaxWidth(progress)
                    .fillMaxHeight()
                    .clip(RoundedCornerShape(50))
                    .background(color)
            )
        }
        if (percent == null) {
            Spacer(Modifier.height(8.dp))
            Text("Ouvre le boîtier pour voir sa charge", color = Faint, fontSize = 12.sp)
        }
    }
}

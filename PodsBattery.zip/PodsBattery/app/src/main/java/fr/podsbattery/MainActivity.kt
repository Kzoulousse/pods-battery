package fr.podsbattery

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val scanner = AirPodsScanner(applicationContext)
        val monitor = ConnectedMonitor(applicationContext)
        val aap = AapClient()
        setContent { App(scanner, monitor, aap) }
    }
}

package fr.podsbattery

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import androidx.core.content.ContextCompat
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/** Écouteur Bluetooth connecté au téléphone, avec la batterie qu'Android connaît (ou null). */
data class ConnectedHeadset(
    val device: BluetoothDevice,
    val name: String,
    val battery: Int?,
    val isApple: Boolean,
)

/**
 * Lit les appareils audio déjà connectés (profils casque et A2DP) et leur niveau de
 * batterie tel que l'affichent les réglages Bluetooth du téléphone.
 */
class ConnectedMonitor(private val context: Context) {

    private val adapter: BluetoothAdapter? =
        context.getSystemService(BluetoothManager::class.java)?.adapter
    private val proxies = mutableMapOf<Int, BluetoothProfile>()
    private val lastBattery = mutableMapOf<String, Int>()

    private val _headset = MutableStateFlow<ConnectedHeadset?>(null)
    val headset: StateFlow<ConnectedHeadset?> = _headset
    private var started = false

    private val listener = object : BluetoothProfile.ServiceListener {
        override fun onServiceConnected(profile: Int, proxy: BluetoothProfile) {
            proxies[profile] = proxy
            refresh()
        }
        override fun onServiceDisconnected(profile: Int) {
            proxies.remove(profile)
            refresh()
        }
    }

    private val receiver = object : BroadcastReceiver() {
        @SuppressLint("MissingPermission")
        override fun onReceive(ctx: Context, intent: Intent) {
            if (intent.action == ACTION_BATTERY_LEVEL_CHANGED) {
                @Suppress("DEPRECATION")
                val device: BluetoothDevice? = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)
                val level = intent.getIntExtra(EXTRA_BATTERY_LEVEL, -1)
                if (device != null && level in 0..100) lastBattery[device.address] = level
            }
            refresh()
        }
    }

    fun start() {
        if (started) return
        val a = adapter ?: return
        runCatching {
            a.getProfileProxy(context, listener, BluetoothProfile.HEADSET)
            a.getProfileProxy(context, listener, BluetoothProfile.A2DP)
            val filter = IntentFilter().apply {
                addAction(ACTION_BATTERY_LEVEL_CHANGED)
                addAction(BluetoothDevice.ACTION_ACL_CONNECTED)
                addAction(BluetoothDevice.ACTION_ACL_DISCONNECTED)
            }
            ContextCompat.registerReceiver(
                context, receiver, filter, ContextCompat.RECEIVER_EXPORTED
            )
            started = true
        }
    }

    fun stop() {
        if (!started) return
        runCatching { context.unregisterReceiver(receiver) }
        proxies.forEach { (p, proxy) -> runCatching { adapter?.closeProfileProxy(p, proxy) } }
        proxies.clear()
        started = false
    }

    @SuppressLint("MissingPermission")
    fun refresh() {
        val devices = runCatching {
            proxies.values.flatMap { it.connectedDevices }.distinctBy { it.address }
        }.getOrDefault(emptyList())

        val pick = devices
            .map { d ->
                val name = runCatching { d.name }.getOrNull() ?: "Écouteurs"
                val battery = readBattery(d) ?: lastBattery[d.address]
                ConnectedHeadset(d, name, battery, isApple = name.contains("AirPods", ignoreCase = true))
            }
            // Priorité aux AirPods, puis à ceux qui donnent une batterie
            .sortedWith(compareByDescending<ConnectedHeadset> { it.isApple }.thenByDescending { it.battery != null })
            .firstOrNull()

        _headset.value = pick
    }

    /** BluetoothDevice.getBatteryLevel() existe mais est masqué : on l'appelle par réflexion. */
    private fun readBattery(d: BluetoothDevice): Int? = runCatching {
        val v = BluetoothDevice::class.java.getMethod("getBatteryLevel").invoke(d) as Int
        v.takeIf { it in 0..100 }
    }.getOrNull()

    companion object {
        const val ACTION_BATTERY_LEVEL_CHANGED = "android.bluetooth.device.action.BATTERY_LEVEL_CHANGED"
        const val EXTRA_BATTERY_LEVEL = "android.bluetooth.device.extra.BATTERY_LEVEL"
    }
}

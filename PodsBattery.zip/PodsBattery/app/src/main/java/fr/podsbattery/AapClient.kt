package fr.podsbattery

import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.lsposed.hiddenapibypass.HiddenApiBypass

/**
 * Parle directement aux AirPods connectés via le protocole AAP d'Apple
 * (canal Bluetooth L2CAP, PSM 0x1001), comme le fait un iPhone.
 * Les AirPods renvoient la batterie exacte (1 %) de chaque écouteur et du boîtier.
 * Protocole documenté par les projets open source CAPod et LibrePods.
 */
class AapClient {

    data class Battery(val percent: Int, val charging: Boolean)

    data class State(
        val deviceAddress: String,
        val left: Battery? = null,
        val right: Battery? = null,
        val case: Battery? = null,
        val single: Battery? = null,
        val updatedAt: Long = System.currentTimeMillis(),
    ) {
        val hasData get() = left != null || right != null || case != null || single != null
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var job: Job? = null
    private var socket: BluetoothSocket? = null
    private var target: String? = null

    private val _state = MutableStateFlow<State?>(null)
    val state: StateFlow<State?> = _state

    /** Dernière erreur, visible dans le diagnostic caché. */
    private val _lastError = MutableStateFlow<String?>(null)
    val lastError: StateFlow<String?> = _lastError

    /** Lance (ou garde) la connexion vers cet appareil. */
    fun connect(device: BluetoothDevice) {
        if (target == device.address && job?.isActive == true) return
        disconnect()
        target = device.address
        job = scope.launch {
            var attempt = 0
            // Peu d'essais : sur beaucoup d'Android < 17 (dont Samsung) ce canal est bloqué
            while (isActive && attempt < 2) {
                try {
                    session(device)
                } catch (e: Exception) {
                    _lastError.value = (e.cause ?: e).let { "${it.javaClass.simpleName}: ${it.message}" }
                }
                closeSocket()
                attempt++
                // Réessaie : vite au début, puis toutes les 15 s
                delay(3_000)
            }
        }
    }

    fun disconnect() {
        job?.cancel()
        job = null
        target = null
        closeSocket()
        _state.value = null
    }

    @SuppressLint("MissingPermission")
    private fun session(device: BluetoothDevice) {
        val sock = createSocket(device)
        socket = sock
        sock.connect()
        _lastError.value = null

        val out = sock.outputStream
        out.write(HANDSHAKE); out.flush()
        NOTIFICATIONS.forEach { out.write(it); out.flush() }
        out.write(INIT_EXT); out.flush()

        val input = sock.inputStream
        val buf = ByteArray(2048)
        while (true) {
            val len = input.read(buf)
            if (len < 0) throw java.io.IOException("Connexion fermée par les AirPods")
            if (len > 0) handlePacket(device.address, buf.copyOf(len))
        }
    }

    private fun handlePacket(address: String, raw: ByteArray) {
        // Message AAP : [04 00 04 00] [commande LE16] [contenu]
        if (raw.size < 7) return
        if (raw[0] != 0x04.toByte() || raw[1] != 0x00.toByte()) return
        val cmd = (raw[4].toInt() and 0xFF) or ((raw[5].toInt() and 0xFF) shl 8)
        if (cmd != CMD_BATTERY_INFO) return

        val p = raw.copyOfRange(6, raw.size)
        val count = p[0].toInt() and 0xFF
        var cur = _state.value?.takeIf { it.deviceAddress == address } ?: State(address)
        var off = 1
        repeat(count) {
            if (off + 5 > p.size) return@repeat
            val type = p[off].toInt() and 0xFF
            val pct = p[off + 2].toInt() and 0xFF
            val chg = p[off + 3].toInt() and 0xFF
            off += 5
            // 127 = valeur fictive après fermeture du boîtier, 255 = déconnecté
            val b = if (pct in 0..100) Battery(pct, chg == 0x01 || chg == 0x05) else null
            cur = when (type) {
                0x01 -> cur.copy(single = b)
                0x02 -> cur.copy(right = b)
                0x04 -> cur.copy(left = b)
                0x08 -> cur.copy(case = b)
                else -> cur
            }
        }
        _state.value = cur.copy(updatedAt = System.currentTimeMillis())
    }

    /** Socket L2CAP "classique" : l'API est masquée par Android, on la débloque. */
    private fun createSocket(device: BluetoothDevice): BluetoothSocket {
        runCatching { HiddenApiBypass.addHiddenApiExemptions("Landroid/bluetooth/") }
        val m = BluetoothDevice::class.java.getDeclaredMethod(
            "createInsecureL2capSocket", Int::class.javaPrimitiveType
        )
        return m.invoke(device, PSM) as BluetoothSocket
    }

    private fun closeSocket() {
        runCatching { socket?.close() }
        socket = null
    }

    companion object {
        private const val PSM = 0x1001
        private const val CMD_BATTERY_INFO = 0x0004

        private val HANDSHAKE = bytes(
            0x00, 0x00, 0x04, 0x00, 0x01, 0x00, 0x02, 0x00,
            0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
        )
        private val NOTIFICATIONS = listOf(
            bytes(0x04, 0x00, 0x04, 0x00, 0x0F, 0x00, 0xFF, 0xFF, 0xEF, 0xFF),
            bytes(0x04, 0x00, 0x04, 0x00, 0x0F, 0x00, 0xFF, 0xFF, 0xFF, 0xFF),
        )
        private val INIT_EXT = bytes(
            0x04, 0x00, 0x04, 0x00, 0x4D, 0x00, 0xD7, 0x00,
            0x00, 0x00, 0x00, 0x00, 0x00, 0x00
        )

        private fun bytes(vararg v: Int) = ByteArray(v.size) { v[it].toByte() }
    }
}

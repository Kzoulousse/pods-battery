package fr.podsbattery

/**
 * Décode le paquet "proximity pairing" qu'Apple diffuse en Bluetooth LE
 * (données fabricant, identifiant Apple 0x004C, type 0x07, 27 octets).
 */
data class PodsStatus(
    val model: String,
    val left: Int?,          // en %, null = inconnu / pas dans le boîtier
    val right: Int?,
    val case: Int?,
    val leftCharging: Boolean,
    val rightCharging: Boolean,
    val caseCharging: Boolean,
    val rssi: Int,
    val timestamp: Long,
)

object AirPodsParser {

    private val MODELS = mapOf(
        0x0220 to "AirPods",
        0x0F20 to "AirPods 2",
        0x1320 to "AirPods 3",
        0x1920 to "AirPods 4",
        0x1B20 to "AirPods 4",
        0x0E20 to "AirPods Pro",
        0x1420 to "AirPods Pro 2",
        0x2420 to "AirPods Pro 2",
        0x0A20 to "AirPods Max",
    )

    fun parse(d: ByteArray, rssi: Int): PodsStatus? {
        if (d.size < 9 || d[0] != 0x07.toByte()) return null
        fun u(i: Int) = d[i].toInt() and 0xFF

        val modelId = (u(3) shl 8) or u(4)
        // Si le bit 0x02 du quartet haut de l'octet 5 est à 0, gauche et droite sont inversés
        val flipped = ((u(5) shr 4) and 0x02) == 0

        val hi = u(6) shr 4
        val lo = u(6) and 0x0F
        val chargeBits = u(7) shr 4
        val caseRaw = u(7) and 0x0F

        fun pct(n: Int): Int? = if (n in 0..10) n * 10 else null

        return PodsStatus(
            model = MODELS[modelId] ?: "AirPods",
            left = pct(if (flipped) hi else lo),
            right = pct(if (flipped) lo else hi),
            case = pct(caseRaw),
            leftCharging = if (flipped) (chargeBits and 0b010) != 0 else (chargeBits and 0b001) != 0,
            rightCharging = if (flipped) (chargeBits and 0b001) != 0 else (chargeBits and 0b010) != 0,
            caseCharging = (chargeBits and 0b100) != 0,
            rssi = rssi,
            timestamp = System.currentTimeMillis(),
        )
    }
}
